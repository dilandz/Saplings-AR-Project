﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class itemProp : MonoBehaviour
{

    [SerializeField] private string type;
    [SerializeField] private int numOfItems;
    [SerializeField] private string attachableObj;
    [SerializeField] private bool isFull = false;

    public bool getIsFull()
    {
        return isFull;
    }

    public void setIsFull(bool _isFull)
    {
        isFull = _isFull;
    }
    public void remove()
    {
        gameObject.GetComponentInParent<itemProp>().setIsFull(false); //fix
        Destroy(gameObject);
    }
    public string getType() 
    {
        return type;
    }
    public string getAttachableObj() 
    {
        return attachableObj;
    }
    public int getNumOfItems()
    {
        return numOfItems;
    }

    public bool useItems(int numToUse = 1)
    {
        if (numToUse <= numOfItems) 
        {
            numOfItems = numOfItems - numToUse;
            return true;
        }
        return false;
    }
}
