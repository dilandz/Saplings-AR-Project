using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemies : MonoBehaviour
{
    public GameObject enemy;
    [SerializeField] private float spawnDelay = 10;
    [SerializeField] private float radius = 10;
    [SerializeField] private float spawnTimer;
    private Vector3 spawnPosition;

    void Start()
    {
    }

    void Update()
    {     
        spawnPosition = new Vector3( transform.position.x + Random.Range(-radius, radius), 0, transform.position.z + Random.Range(-radius, radius));

        if (spawnTimer >= spawnDelay)
        {
            spawnTimer = 0;
            Instantiate(enemy, spawnPosition, Quaternion.identity);
        }
        spawnTimer += Time.deltaTime;
    }
}

