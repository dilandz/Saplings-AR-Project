﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveNDamage : MonoBehaviour
{
    [SerializeField] private float EnemyMovementSpeed = 1f;
    [SerializeField] private float stopDistance = 1f;
    [SerializeField] private GameObject targetPlant;
    [SerializeField] private float attackCooldown;
    [SerializeField] private float attackDamage;
    private float distanceFromTarget;
    private float attackCooldownTimer;
    

    private void targetRandom()
    {
        targetPlant = GameObject.FindGameObjectWithTag("plant");
    }

    private void targetClosest()
    {
        
    }

    private void movement()
    {
        Vector3 displacementFromPlant = targetPlant.transform.position - transform.position;
        Vector3 direction = displacementFromPlant.normalized;
        Vector3 velocity =  direction * EnemyMovementSpeed;
        Vector3 moveAmount = velocity * Time.deltaTime;

        distanceFromTarget = displacementFromPlant.magnitude;

        transform.LookAt(targetPlant.transform);

        if (distanceFromTarget > stopDistance)
        {
            transform.Translate(moveAmount, Space.World);
        }
        else 
        {
            damagePlant();
        }
           
    }

    private void damagePlant() 
    {
        if (attackCooldownTimer >= attackCooldown) 
        {
            targetPlant.GetComponent<plant>().damage(attackDamage);
            attackCooldownTimer = 0;
        }
        attackCooldownTimer += Time.deltaTime;
    }

    private void Start()
    {
        targetRandom();
    }

    void Update()
    {
        targetRandom();
        movement();
        //Damaging the plant and the damage faced by the enemy is not implemented :( sorry
    }
}

