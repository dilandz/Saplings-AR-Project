﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class useItem : MonoBehaviour
{
    public GameObject clipBoard; // set uing inventory but public for demo //set to private later
    public Camera cam;

    private int range = 100;

    public void setClipBoard(GameObject obj) 
    {
        clipBoard = obj;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1")) //when clicked
        {
            Debug.Log(clipBoard.transform.name);
            string objType = clipBoard.GetComponent<itemProp>().getType();
            Debug.Log(objType);

            if (objType == "placable")
            {
                gridPlaceObj();
            }
            else if (objType == "attachable") 
            {
                attachObj();
            }

            
        }
    }

    private Vector3 transformToGrid(Vector3 oldPos) 
    {
        Vector3 newPos = new Vector3(Mathf.Round(oldPos.x), Mathf.Round(oldPos.y), Mathf.Round(oldPos.z));
        return newPos;
    }

    private void gridPlaceObj() 
    {
        RaycastHit hit;
        if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hit, range)) 
        {
            Debug.Log(hit.transform.name);
            if (clipBoard.GetComponent<itemProp>().useItems(1)) // reduces item count and checks if over 
            {
                Instantiate(clipBoard, transformToGrid(hit.point), Quaternion.identity);
            }
            
        }
    }

    private void attachObj() 
    {
        RaycastHit hit;
        if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hit, range) && hit.transform.name == clipBoard.GetComponent<itemProp>().getAttachableObj())
        {
            Debug.Log(clipBoard.GetComponent<itemProp>().getAttachableObj() + ":" + hit.transform.name);

            if (clipBoard.GetComponent<itemProp>().useItems(1) && !hit.transform.GetComponent<itemProp>().getIsFull()) 
            {
                GameObject temp = Instantiate(clipBoard, hit.transform.position, Quaternion.identity);
                hit.transform.GetComponent<itemProp>().setIsFull(true);

                temp.transform.SetParent(hit.transform);
            }
            

            
        }
    }
}
