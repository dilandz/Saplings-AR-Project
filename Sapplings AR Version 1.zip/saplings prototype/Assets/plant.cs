﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class plant : itemProp
{
    private enum growthStage { SEED, SAPLING, PLANT, BIGPLANT };
    [SerializeField] private growthStage stage = growthStage.SEED;
    [SerializeField] private float growthTime = 5;
    [SerializeField] private float dryUpRate = 1;
    private float growthTimer;
    private bool isGrowing = true;
    [SerializeField] private float health = 100;




    private void Start()
    {
        growthTimer = growthTime + Random.Range(-5, 5);
    }

    public void damage(float _damage)
    {
        health -= _damage;
    }
    public void heal(float _heal)
    {
        health -= _heal;
    }
    public float getHealth() 
    {
        return health;
    }
 
    private void grow() 
    {
        if (isGrowing) 
        {
            growthTimer -= Time.deltaTime;
        }
        

        if (growthTimer <= 0) 
        {
            growthTimer = growthTime + Random.Range(-5,5);
            stage++;
            switch (stage) 
            {
                case growthStage.SEED:
                    transform.localPosition = new Vector3(0, 0.2f, 0);
                    break;
                case growthStage.SAPLING:
                    transform.localPosition = new Vector3(0, 0.4f, 0);
                    break;
                case growthStage.PLANT:
                    transform.localPosition = new Vector3(0, 0.6f, 0);
                    break;
                case growthStage.BIGPLANT:
                    transform.localPosition = new Vector3(0, 1, 0);
                    isGrowing = false;
                    break;
            }
        }

        if (health < 0) 
        {
            remove();
        }
    }

    private void dryUp()
    {
        health -= dryUpRate * Time.deltaTime;
    }

    private void Update()
    {
        grow();
        dryUp();
    }

}
